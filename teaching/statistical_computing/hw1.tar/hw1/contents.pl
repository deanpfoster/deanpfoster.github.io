# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate contents original text with physical files.

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%hw1.html%:%No Title' unless ($toc_section_info{$key}); 

1;

