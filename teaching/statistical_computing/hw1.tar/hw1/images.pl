# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate images original text with physical files.

$key = q/{_inline}$backslash${_inline}/;
$cached_env_img{$key} = ' <IMG WIDTH=8 HEIGHT=30 ALIGN=MIDDLE ALT="tex2html_wrap_inline27" SRC="img1.gif"  > '; 

1;

