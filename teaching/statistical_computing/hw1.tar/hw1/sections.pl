# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate sections original text with physical files.

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%hw1.html%:%No Title' unless ($section_info{$key}); 
$done{"hw1.html"} = 1;

1;

